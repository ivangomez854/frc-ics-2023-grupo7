import {Component} from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent {
textoFooter = 'TRABAJO PRÁCTICO N 6 - GRUPO 7 - CÁTEDRA INGENIERÍA Y CALIDAD DE SOFTWARE'
universidad = 'UTN-FRC'
}
