export enum TiposEnvioEnum {
  LO_ANTES_POSIBLE,
  PACTAR_FECHA
}
