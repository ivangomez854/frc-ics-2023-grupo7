export enum TiposPagoEnum {
  EFECTIVO,
  TARJETA_VISA
}
