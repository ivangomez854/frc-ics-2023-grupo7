export class TarjetaCredito {
  entidad: string;
  nombreTitular: string;
  numeroTarjeta: string;
  vencimiento: Date;
  codigoSeguridad: number;
}
